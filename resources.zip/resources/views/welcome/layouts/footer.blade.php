<!-- Footer -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-4 text-center">
                <a href="tel:0040728683604"><i class="fa fa-phone fa-3x sr-contact"></i>
                <p>+40728 683 604</p></a>
            </div>
            <div class="col-md-2 col-sm-4 text-center">
                <a href="tel:0040730719323"><i class="fa fa-phone fa-3x sr-contact"></i>
                <p>+40730 719 323</p></a>
            </div>            
            <div class="col-md-2 col-sm-4 text-center">
                <a href="tel:0040725085231"><i class="fa fa-phone fa-3x sr-contact"></i>
                <p>+40725 085 231</p></a>
            </div>
            <div class="col-md-2 col-sm-4 text-center">
                <a href="https://www.facebook.com/aurasjobs/" target="_blank"><i class="fa fa-facebook fa-3x sr-contact"></i>
                <p><a href="https://www.facebook.com/aurasjobs.ro" target="_blank">@aurasjobs</a></p>
            </div>
            <div class="col-md-3 col-sm-4 text-center">
                <a href="mailto:&#111;&#102;&#102;&#105;&#099;&#101;&#064;&#097;&#117;&#114;&#097;&#115;&#106;&#111;&#098;&#115;&#046;&#114;&#111;"><i class="fa fa-envelope-o fa-3x sr-contact"></i>
                <p><a href="mailto:&#111;&#102;&#102;&#105;&#099;&#101;&#064;&#097;&#117;&#114;&#097;&#115;&#106;&#111;&#098;&#115;&#046;&#114;&#111;">&#111;&#102;&#102;&#105;&#099;&#101;&#064;&#097;&#117;&#114;&#097;&#115;&#106;&#111;&#098;&#115;&#046;&#114;&#111;</a></p>
            </div>
        </div>
    </div>
</footer>
