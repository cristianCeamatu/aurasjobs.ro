<!-- Footer -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-lg-offset-1 text-center">
                <a href="tel:0040728683604"><i class="fa fa-phone fa-3x sr-contact"></i>
                <p>+40728.683.604</p></a>
            </div>                            
            <div class="col-lg-3 col-lg-offset-1 text-center">
                <a href="tel:0040765711616"><i class="fa fa-phone fa-3x sr-contact"></i>
                <p>+40728.683.604</p></a>
            </div>
            <div class="col-lg-3 col-lg-offset-1 text-center">
                <a href="https://www.facebook.com/aurasjobs/" target="_blank"><i class="fa fa-facebook fa-3x sr-contact"></i>
                <p><a href="https://www.facebook.com/aurasjobs.ro" target="_blank">@aurasjobs</a></p>
            </div>
            <div class="col-lg-3 col-lg-offset-1 text-center">
                <a href="mailto:office@aurasjobs.com"><i class="fa fa-envelope-o fa-3x sr-contact"></i>
                <p><a href="mailto:office@aurasjobs.com">office@aurasjobs.ro</a></p>
            </div>
        </div>
    </div>
</footer>